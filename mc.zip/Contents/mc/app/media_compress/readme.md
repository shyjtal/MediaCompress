V1
@time 2025-07-16
@description 
auto compress media file, including video, image, gif, and so much more, whether file or dir.